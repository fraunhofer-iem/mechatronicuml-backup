Atmel Studio 5 projects require a "src" folder, even if it is empty when all source files are linked and reside in
folders outside a project which is the case for this project.