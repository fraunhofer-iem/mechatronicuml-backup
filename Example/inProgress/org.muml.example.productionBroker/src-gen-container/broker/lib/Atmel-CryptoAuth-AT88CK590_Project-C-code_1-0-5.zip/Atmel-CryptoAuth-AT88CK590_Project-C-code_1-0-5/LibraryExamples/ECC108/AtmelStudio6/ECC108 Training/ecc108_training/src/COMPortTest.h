/*
 * COMPortTest.h
 *
 * Created: 4/8/2013 10:12:00 AM
 *  Author: james.tomasetta
 */ 


#ifndef COMPORTTEST_H_
#define COMPORTTEST_H_

#include <stdio.h>


void comport_test(void);


#endif /* COMPORTTEST_H_ */