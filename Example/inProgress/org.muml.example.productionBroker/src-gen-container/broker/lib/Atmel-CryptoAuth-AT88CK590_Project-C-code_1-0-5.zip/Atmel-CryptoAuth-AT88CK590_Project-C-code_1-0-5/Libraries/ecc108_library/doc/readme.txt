Todo:
The library and examples have to be merged with Edy Gunawan's (Bali team) code.
Until this is done, this source should not be copied to the distributable folder,
but only the distributable should be worked with in case quick patches are needed.