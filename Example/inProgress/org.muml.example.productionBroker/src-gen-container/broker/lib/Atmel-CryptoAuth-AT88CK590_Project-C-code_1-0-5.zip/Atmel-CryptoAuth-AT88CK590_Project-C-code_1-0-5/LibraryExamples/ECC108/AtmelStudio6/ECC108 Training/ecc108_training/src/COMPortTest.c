/*
 * COMPortTest.c
 *
 * Created: 4/8/2013 10:11:48 AM
 *  Author: james.tomasetta
 */ 
#include "COMPortTest.h"    




void comport_test(void)
{
	while(1) {
		printf("COM Port OK\n\r");
	}
}
