Install Instructions
1. Copy Folder "RealTimeCoordinationLibrary" into the folder "C:\Program Files (x86)\Dymola 2013\Modelica\Library"
2. Start Dymola
3. File->Libraries->RealTimeCoordinationLibrary


Contact Person:

Uwe Pohlmann, M. Sc. 

Address:
Fachgruppe Softwaretechnik
Heinz Nixdorf Institut
Universit�t Paderborn
Zukunftsmeile 1
33102 Paderborn

E-Mail:
upohl (at) uni-paderborn.de

Telephone:
+49 5251 - 54 65 156
Facsimile:
+49 5251 60-3985
Room:
ZM1.02-06
